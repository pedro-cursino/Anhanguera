
public class Principal {

	public static void main(String[] args) {
		// Criação do objeto CONTA
		Cliente cli = new Cliente();
		Conta c = new Conta(cli);
		if (c.sacar(50)) {
			System.out.println("Saque realizado com sucesso.");
		}
		else {
			System.out.println("Não foi possível realizar o saque.");
		}
		c.depositar(30);
		System.out.println("Saldo atual: " + c.getSaldo());
	}

}
