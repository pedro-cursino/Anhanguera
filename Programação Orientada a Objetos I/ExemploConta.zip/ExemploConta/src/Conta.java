
public class Conta {
	private String numero;
	private String agencia;
	private double saldo;
	private double limite;
	private Cliente donoDaConta;
	
	public Conta(Cliente cliente) {
		this.limite = 100;
		this.setDonoDaConta(cliente);
	}
	
	public double getSaldo() {
		return this.saldo;
	}
	
	public String getNumero() {
		return this.numero;
	}
	
	public void setNumero(String num) {
		this.numero = num;
	}
	
	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	// Método saque
	public boolean sacar(double valor) {
		if (this.saldo + this.limite < valor) {
			return false;
		}
		else {
			return true;
		}
	}
	
	// Método depositar
	public void depositar(double valor) {
		this.saldo += valor;
	}

	public Cliente getDonoDaConta() {
		return donoDaConta;
	}

	public void setDonoDaConta(Cliente donoDaConta) {
		this.donoDaConta = donoDaConta;
	}
	
	// Criar o método EXTRATO
}