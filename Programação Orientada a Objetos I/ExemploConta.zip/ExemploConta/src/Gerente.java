
public class Gerente extends Funcionario {
	String senha;
	int numFuncGerenciados;
	
	public boolean autenticar(String senha) {
		if (this.senha == senha) {
			System.out.println("Acesso permitido.");
			return true;
		}
		else {
			System.out.println("Acesso negado!");
			return false;
		}
	}
}
