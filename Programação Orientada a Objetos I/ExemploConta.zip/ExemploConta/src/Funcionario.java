
public class Funcionario {
	String nome;
	String cpf;
	double salario;
}
